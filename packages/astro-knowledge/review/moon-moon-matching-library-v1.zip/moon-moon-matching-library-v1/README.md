# Moon-Moon Matching Library v1
144 directional records resolved from the author's 78 original cards (MOON-COMPATIBILITY-CARDS.md).
- Reversals are pure grammatical role-swaps; no wording changes. Reversed records use singular they for {friend}.
- {friend} is the render placeholder for the other person's name.
- relation column gives the sign-to-sign angle; the measured Moon-to-Moon aspect remains an app slot per the author's template note.
- moon-source-review-ledger.csv documents source verification method (Fearrington, March & McEvers Vol 5, Hayden, Forrest).
- The long-form 5-paragraph variant (moon-compatibility-full-writeups.md) exists separately for a detail surface.

## Rendering rule
Each record's `text` is ONE paragraph. Do not split on sentences or semicolons — the semicolon sentence ("You X; {friend} Y.") is a deliberate paired clause and must stay on one line. Paragraph breaks exist only where \n\n appears in `text`. Format is now four paragraphs: domain lead-in / reader depth block / other-person depth block (or both-directions line for same-sign) / pair dynamic. No other splitting. Replace {friend} with the other person's display name.

## Tags
Each record carries a `tag` describing the comparison type, derived from the sign-to-sign relation: Two of a kind (same sign), Ease (trine / same element), Support (sextile), Friction (square), Push and pull (opposition), Adjustment (quincunx), Close but different (semisextile). Render as a chip/label on the card if desired.

Tag administration: store the tag vocabulary as its own editable table in the content dashboard, keyed by relation (7 rows: same, semisextile, sextile, square, trine, quincunx, opposition). Records carry a relation field; resolve the chip label from the vocabulary table at render time so an admin edit to one label updates every record of that relation at once. The per-record tag field in this JSON is the imported default; if an admin has edited a vocabulary row, the edit wins over future bulk imports (same protection rule as dashboard-edited records). The same vocabulary table should serve all planet layers when they ship.
