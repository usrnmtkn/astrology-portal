# Moon–Moon Compatibility Library v1 — Codex Handoff (final, Jul 21 2026)

## What this is
144 author-final records covering every Moon-sign pairing (12 same-sign + 132 directional cross-sign). This version supersedes all previous imports: all 12 sign depth blocks, all 12 same-sign records, and all 66 pair dynamics have been through the author's editorial pass and a canon-consistency audit. Re-import everything; do not merge with older copies.

## File to import
`moon-compatibility-library.json` — array of 144 records:
- `reader_moon`, `other_moon` — capitalized sign names. Key a lookup as `compatibility.moon.{reader_moon.lower()}.{other_moon.lower()}`. Directionality matters: `aries.taurus` addresses the Aries-Moon reader about a Taurus-Moon friend; `taurus.aries` is the mirror. Never swap them.
- `text` — full display copy. Paragraphs are separated by `\n\n` ONLY (4 paragraphs: domain sentence, reader block, friend block, pair dynamics; same-sign records: domain, merged portrait, element paragraph, challenge). Preserve paragraph breaks exactly; no other markup.
- `{friend}` placeholder — replace with the other person's NAME every time it appears. Never substitute pronouns; the grammar is built for a name ("Chris's Moon is in Cancer, meaning they..."). Friend blocks use singular they with plural verbs by design.
- `relation` — same | semisextile | sextile | square | trine | quincunx | opposition (sign-distance relation, not a measured aspect).
- `tag` — display chip, keyed to relation: same→"Two of a kind", trine→"Ease", sextile→"Support", square→"Friction", opposition→"Push and pull", quincunx→"Adjustment", semisextile→"Close but different". Keep this vocabulary admin-editable as a table keyed by relation.
- `source`, `format`, `domain` — provenance/structure metadata; not for display.

## Rules that must hold in the app
1. Do not edit, truncate, or auto-summarize `text`. Every line is author-final.
2. Unpin any previously pinned records (e.g., compatibility.moon.scorpio.cancer) — this file is the single source of truth.
3. No-birth-time handling: see `TLDR-Compatibility-No-BirthTime-Spec.md` in this package. If the Moon sign is ambiguous for the birth date (sign changes that day), show the sign picker with foundations; never silently default to noon.
4. Render `{friend}` before display in every surface (cards, notifications, shares).

## Reference files in this package
- `MOON-COMPATIBILITY-CARDS-RESOLVED.md` — human-readable render of all 144 records for QA diffing.
- `moon-verification-ledger.md` + `moon-source-review-ledger.csv` — source-grounding verification.
- `moon-compatibility-coverage.csv` — coverage matrix.
- `MOON-COMPATIBILITY-CARDS.md` — the author's original 78 cards (historical reference only; do not import).
- `README.md` — original package notes (v1 build).
